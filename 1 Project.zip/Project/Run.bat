@echo off
cd App
start "" "chrome" "http://127.0.0.1:5000"
py -3.12 app.py
pause
